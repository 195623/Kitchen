﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Kitchen;

namespace Kitchen_main
{
    class Program
    {
        static void Main()
        {
            Fridge fridge;











            Console.ReadKey();
        }








    }

    

    

    

    

    
}
